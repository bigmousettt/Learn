# 使用深度学习进行网络入侵检测
## 实现程序结构
  - Datasets
    - **bin_data.csv** - CSV 二元分类数据集文件
    - **multi_data.csv** - CSV 多类分类数据集文件
    - **KDDTrain+.txt** - 原始数据集
  - Labels
    - **le1_classes.npy** - 包含二元标签的Numpy文件
    - **le2_classes.npy** - 包含多类标签的Numpy文件
  - Models
    - **ae_binary.json** - Trained Auto Encoder Model JSON File for Binary Classification（二分类AE模型）
    - **ae_multi.json** - Trained Auto Encoder Model JSON File for Multi-class Classification（多分类AE模型）
    - **knn_binary.pkl** - Trained K-Nearest-Neighbor Model Pickle File for Binary Classification（二分类K-NN模型）
    - **knn_multi.pkl** - Trained K-Nearest-Neighbor Model Pickle File for Multi-class Classification（多分类K-NN模型）
    - **lda_binary.pkl** - Trained Linear Discriminant Analysis Model Pickle File for Binary Classification（二分类LDA模型）
    - **lda_multi.pkl** - Trained Linear Discriminant Analysis Model Pickle File for Multi-class Classification（多分类LDA模型）
    - **lst_binary.json** - Trained Long Short-Term Memory Model JSON File for Binary Classification（二分类LSTM模型）
    - **lsvm_binary.pkl** - Trained Linear Support Vector Machine Model Pickle File for Binary Classification（二分类LSVM模型）
    - **lsvm_multi.pkl** - Trained Linear Support Vector Machine Model Pickle File for Multi-class Classification（多分类LSVM模型）
    - **mlp_binary.json** - Trained Multi Layer Perceptron Model JSON File for Binary Classification（二分类MLP模型）
    - **mlp_multi.json** - Trained Multi Layer Perceptron Model JSON File for Multi-class Classification（多分类MLP模型）
    - **qda_binary.pkl** - Trained Quadratic Discriminant Analysis Model Pickle File for Binary Classification（二分类QDA模型）
    - **qda_multi.pkl** - Trained Quadratic Discriminant Analysis Model Pickle File for Multi-class Classification（多分类QDA模型）
    - **qsvm_binary.pkl** - Trained Quadratic SUpport Vector Machine Model Pickle File for Binary Classification（二分类QSVM模型）
    - **qsvm_multi.pkl** - Trained Quadratic Support Vector Machine Model Pickle File for Multi-class Classification（多分类QSVM模型）
  - Weights
    - **ae_binary.h5** - Model weights of Auto Encoder Model for Binary Classification （二分类AE模型的模型权重）
    - **ae_multi.h5** - Model weights of Auto Encoder Model for Multi-class Classification （多分类AE模型的模型权重）
    - **lst_binary.h5** - Model weights of Long Short-Term Memory Model for Binary Classification （二分类LSTM模型的模型权重）
    - **mlp_binary.h5** - Model weights of Multi Layer Perceptron Model for Binary Classification（二分类MLP模型的模型权重）
    - **mlp_multi.h5** - Model weights of Multi Layer Perceptron Model for Multi-class Classification （多分类MLP模型的模型权重）
  - Plots
    - **Pie_chart_binary.png** - Pie chart of Binary Classification （二分类的饼图）
    - **Pie_chart_multi.png** - Pie chart of Multi-class Classification （多分类饼图）
    - **ae_binary.png** - Auto Encoder Model Summary for Binary Classification 
    - **ae_binary_accuracy.png** - Auto Encoder Accuracy Plot for Binary Classification （二分类的AE模型精度图）
    - **ae_binary_loss.png** - Auto Encoder Loss Plot for Binary Classification（二分类的AE模型损失函数图）
    - **ae_multi.png** - Auto Encoder Model Summary for Multi-class Classification
    - **ae_multi_accuracy.png** - Auto Encoder Accuracy Plot for Multi-class Classification （多分类的AE模型精度图）
    - **ae_multi_loss.png** - Auto Encoder Loss Plot for Multi-class Classification（多分类的AE模型损失函数图）
    - **lstm_binary.png** - Long Short-Term Memory Model Summary for Binary Classification
    - **lstm_binary_accuracy.png** - Long Short-Term Memory Accuracy Plot for Binary Classification （二分类的LSTM模型精度图）
    - **lstm_binary_loss.png** - Long Short-Term Memory Loss Plot for Binary Classification（二分类的LSTM模型损失函数图）
    - **mlp_binary.png** - Multi Layer Perceptron Model Summary for Binary Classification
    - **mlp_binary_accuracy.png** - Multi Layer Perceptron Accuracy Plot for Binary Classification （多分类的LSTM模型精度图）
    - **mlp_binary_loss.png** - Multi Layer Perceptron Loss Plot for Binary Classification（多分类的LSTM模型损失函数图）
    - **mlp_multi.png** - Multi Layer Perceptron Model Summary for Multi-class Classification 
    - **mlp_multi_accuracy.png** - Multi Layer Perceptron Accuracy Plot for Multi-class Classification （多分类的MLP模型精度图）
    - **mlp_multi_loss.png** - Multi Layer Perceptron Loss Plot for Multi-class Classification（多分类的MLP模型损失函数图）
  - **Classifiers_NSL-KDD.ipynb** - Machine Learning Classifiers IPYNB file  （机器学习分类器文件）
  - **Data_Preprocessing_NSL-KDD.ipynb** - Data Preprocessing IPYNB File （数据处理文件）
  - **Intrusion_Detection.ipynb** - Combined IPYNB File （总的文件，包括数据处理和基于机器学习进行入侵检测）

## Dataset
The NSL-KDD dataset from the Canadian Institute for Cybersecurity (updated version of the original KDD Cup 1999 Data (KDD99)
https://www.unb.ca/cic/datasets/nsl.html

## Prerequisites
 - Keras 
 - Sklearn 
 - Pandas 
 - Numpy
 - Matplotlib
 - Pickle

## Running the Notebook
The notebook can be run on 
 - Jupyter Notebook
